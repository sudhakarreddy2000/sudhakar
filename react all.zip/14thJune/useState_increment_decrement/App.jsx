import { useState } from "react"
function App() {
const [state, setState]=useState(0)
const add=()=>{
    setState(state+1)
}
const del=()=>{
    setState(state-1)
}
    return (
        <>
            <h2>updating state in react</h2>
            <h2>{state}</h2>
            <button onClick={add}>increment </button>
            <button onClick={del}>decrement </button>
        </>
    )
}
export default App