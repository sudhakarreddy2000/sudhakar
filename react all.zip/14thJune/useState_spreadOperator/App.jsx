import { useState } from "react"
function App() {
    const [state, setState] = useState({f_name:'Ajay',l_name:'Kumar'})
    const handler = () => {
        //setState({f_name:'Vijay',l_name:'Seth'})
        setState({...state, f_name:'Vijay'})
    }
    return (
        <>
            <h2>updating state in react</h2>
            <h2>First name is {state.f_name} and last name is {state.l_name}</h2>
            <button onClick={handler}>update </button>
        </>
    )
}
export default App