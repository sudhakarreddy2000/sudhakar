import { useState } from "react"
function App() {
let users=['Raana','Jagdish','Anil','Sunil']
const [state, setState]=useState(users)


    return (
        <>
            <h2>updating state in react</h2>
            {state.map((item)=><li>{item}</li>)}
        
                    </>
    )
}
export default App