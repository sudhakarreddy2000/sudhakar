import { useState } from "react"
function App() {
let users=['Raana','Jagdish','Anil','Sunil']
let users1=['Seema','Mourya','Shreya','Seetha']
const [state, setState]=useState(users)
const handler=()=>{
    setState(users1)
}

    return (
        <>
            <h2>updating state in react</h2>
            <h2>{state}</h2>
            <button onClick={handler}>update </button>
                    </>
    )
}
export default App