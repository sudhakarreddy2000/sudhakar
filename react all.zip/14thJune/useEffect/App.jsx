import { useState, useEffect } from "react"
function App() {
    const [state, setState] = useState([])
useEffect(()=>{
fetch('https://jsonplaceholder.typicode.com/todos')
        .then(response => response.json())
        //.then(json => console.log(json))
        .then(json => setState(json))
},[])

    
    return (
        <>
            <h2>Api Example</h2>
            {state.map((item) => <li>{item.title}</li>)}
        </>
    )
}
export default App