import { useState } from "react"
function App() {
const [state, setState]=useState("React")
const handler=()=>{
    if(state=="React"){
        setState("Single Page Application")
    }else{
        setState("React")
    }
    
}
    return (
        <>
            <h2>updating state in react</h2>
            <h2>{state}</h2>
            <button onClick={handler}>clickme </button>
        </>
    )
}
export default App