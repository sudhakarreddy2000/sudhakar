import { createRoot } from "react-dom/client";
const obj=new Date();
let h=obj.getHours();
let m=obj.getMinutes();
let s=obj.getSeconds();
let dt=obj.getDate();
let mt=obj.getMonth()+1;
let yr=obj.getFullYear()
let time=obj.toLocaleTimeString();
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to React world</h1>
    <h4>{Date()}</h4>
    <h4>{h}:{m}:{s}</h4>
    <h4>{dt}-{mt}-{yr}</h4>
    <h4>{time}</h4>

    </>
)