import { createRoot } from "react-dom/client";
var courses=['React','Java','Mongo','Node','sql']
const person={
    name:'Vikas',
    place:'Delhi',
    age:22
}
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to React world</h1>
    <h4>{courses}</h4>
    <h4>{courses[2]}</h4>
    <h4>{person.name}</h4>
    <h4>{person.place}</h4>
    </>
)