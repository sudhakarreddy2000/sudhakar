import { createRoot } from "react-dom/client";
import pic from './boy.jpeg'
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to React world</h1>
    <img src={pic} alt="" width="200px"/>
    <br/>
    <img src="vite.svg"/>
    </>
)