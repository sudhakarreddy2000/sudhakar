import { createRoot } from "react-dom/client";
var uid="React"
let pwd="Software"
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to React world</h1>
    <h3>Hello {uid}</h3>
    <h3>Password is {pwd}</h3>
    <h3>{10+10}</h3>
    <h3>{10*10}</h3>
    </>
)