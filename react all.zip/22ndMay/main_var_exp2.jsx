import { createRoot } from "react-dom/client";
var uid=prompt("Enter user id here")
var num1=prompt("Enter first number")
var num2=prompt("Enter second number")
var result=Number(num1)+Number(num2)
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to React world</h1>
    <h3>Hello {uid}</h3>
    <h3>{result}</h3>
    </>
)