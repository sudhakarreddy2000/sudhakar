import { useState } from 'react'
export default function Del() {
        const [del, setDel]=useState(100)
        const delHandler=()=>{
            setDel(del-1)
        }
  return (
    <>
          {del}
      <button onClick={delHandler}>Del</button>
    </>
  )
}
