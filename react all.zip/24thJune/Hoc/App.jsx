import Add from './Add'
import Del from './Del'
import Hoc from './Hoc'
function App() {
return (
<>
<Hoc cmp={Add}/>
<Hoc cmp={Del}/>
</>
)
}
export default App