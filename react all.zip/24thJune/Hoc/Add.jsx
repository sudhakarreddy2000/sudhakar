import { useState } from 'react'
export default function Add() {
    const [add, setAdd]=useState(0)
    const addHandler=()=>{
        setAdd(add+1)
    }
  return (
    <>
    {add}
      <button onClick={addHandler}>Add</button>
    </>
  )
}
