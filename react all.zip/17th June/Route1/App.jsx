import {BrowserRouter,Routes,Route} from 'react-router-dom'
function App() {
       return (
        <>
        <BrowserRouter>
        <Routes>
            <Route path="/" element={<h2>Welcome to React</h2>}  />
            <Route path="/about" element={<h2>About</h2>}  />
            <Route path="/contact" element={<h2>Contact</h2>}/>
        </Routes>
        </BrowserRouter>
        </>
    )
}
export default App