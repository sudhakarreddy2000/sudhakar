import { useState, useEffect, useMemo } from "react"
function App() {
    const [add, setAdd] = useState(0)
    const [del, setDel] = useState(100)
    const addition = () => {
        setAdd(add + 1)
    }
    const deletion = () => {
        setDel(del - 1)
    }

    // const multiply=()=>{
    //     console.log("Hello")
    //     return add*5;
    // }
    const multiply = useMemo(function multiplication() {
        console.log("Hello")
        return add * 5;
    }, [add])
    return (
        <>
            <h2>useMemo() hook Example</h2>
            <h3>{add}</h3>
            <h3>{multiply}</h3>
            <button onClick={addition}>Add</button>
            <br />
            <button onClick={deletion}>Del</button>
            {del}
        </>
    )
}
export default App