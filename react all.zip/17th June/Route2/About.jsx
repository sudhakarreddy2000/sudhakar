import React from 'react'

export default function About() {
  return (
    <div>
      <h2>About us </h2>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio rem exercitationem alias. Unde perspiciatis consectetur eum dolores molestiae, fuga labore, beatae fugiat quis ut harum commodi consequatur libero. Nulla quod reprehenderit vitae, perspiciatis cupiditate vero velit quisquam excepturi nam fuga distinctio optio soluta asperiores iure minus, consectetur eos ut molestiae, non aut sapiente? Ut sequi, aliquam doloremque velit repellat provident dolor soluta dicta, aspernatur excepturi itaque. Suscipit voluptatibus amet distinctio et iusto dolore voluptatem error, facilis assumenda quae? Excepturi ipsam repellat ratione atque nihil quasi ea possimus ipsum nesciunt omnis? Cumque laborum, molestias saepe iste et accusantium incidunt porro eos.
      </p>
    </div>
  )
}
