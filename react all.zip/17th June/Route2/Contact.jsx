import React from 'react'

export default function Contact() {
  return (
    <div>
      <h2>Contact</h2>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque optio molestiae voluptates molestias dolores rem animi, praesentium quod quaerat officiis ratione magni laborum accusantium perspiciatis modi cupiditate est fugiat libero, ab quos eius harum! Nemo suscipit ipsum, corporis, magnam magni corrupti sapiente quisquam enim laborum odio dolorum, tempora eveniet ullam vitae! Aliquam tenetur, fugiat libero fugit sint in dignissimos sit iusto modi quis unde! Sequi eum alias quod debitis iste labore obcaecati provident est porro maiores, voluptatibus, fugiat esse sapiente iusto at libero laborum, quisquam dolores voluptatem nulla? Facilis iure possimus laborum aliquid ullam ducimus ea, optio praesentium distinctio aut!
      </p>
    </div>
  )
}
