import {BrowserRouter,Routes,Route,Link} from 'react-router-dom'
import About from './About'
import Contact from './Contact'
function App() {
       return (
        <>
        <BrowserRouter>
        {/* <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/contact">Contact</a> */}
        <Link to="/">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/contact">Contact</Link>
        <Routes>
            <Route path="/" element={<h2>Welcome to React</h2>}  />
            <Route path="/about" element={<About/>}  />
            <Route path="/contact" element={<Contact/>}/>
        </Routes>
        </BrowserRouter>
        </>
    )
}
export default App