import { createRoot } from "react-dom/client";
import '../node_modules/bootstrap/dist/css/bootstrap.css'
createRoot(document.getElementById('root')).render(
    <>
    <div className="container">
        <div className="row">
            <div className="col-md-6 bg-danger">left</div>
            <div className="col-md-6 bg-success">right</div>
        </div>
    </div>
    </> 
)