import { createRoot } from "react-dom/client";
let num=40;
let result;
if(num>=100){
    result="it is currect"
}else{
    result="it is not valid"
}
createRoot(document.getElementById('root')).render(
    <>
    <h3>{result}</h3>
    </> 
)