import { createRoot } from "react-dom/client";
import p1 from './images/smile.png'
import p2 from './images/cry.png'
let uid=prompt("Enter uid here")
let result;
if(uid=="react"){
    result=p1
}else{
    result=p2
}
createRoot(document.getElementById('root')).render(
    <>
    <img src={result} />
    </> 
)