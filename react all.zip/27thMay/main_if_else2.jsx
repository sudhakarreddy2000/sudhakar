import { createRoot } from "react-dom/client";
let marks=prompt("Enter marks here")
let message;
if(marks<=40){
    message="Failed"
}else{
    message="Passed"
}
createRoot(document.getElementById('root')).render(
    <>
    <h3>{message}</h3>
    </> 
)