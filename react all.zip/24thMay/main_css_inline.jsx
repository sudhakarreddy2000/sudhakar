import { createRoot } from "react-dom/client";
createRoot(document.getElementById('root')).render(
    <>
    <h1 style={{color:'red', background:'yellow'}}>Welcome to React world</h1>
    </>
)