import { createRoot } from "react-dom/client";
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import pic from './boy.jpeg'
createRoot(document.getElementById('root')).render(
    <>
<h1 className="text-primary bg-info">Welcome to React world</h1>
<button className="btn btn-success">clickme</button>
<button className="btn btn-danger">clickme</button>
<button className="btn btn-info">clickme</button>
<button className="btn btn-primary">clickme</button>
<br/>
<img src={pic} className="img-fluid"/>
    </> 
)