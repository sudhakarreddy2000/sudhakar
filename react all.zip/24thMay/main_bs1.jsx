import { createRoot } from "react-dom/client";
import '../node_modules/bootstrap/dist/css/bootstrap.css'
createRoot(document.getElementById('root')).render(
    <>
    <h1 className="text-primary bg-info">Welcome to React world</h1>
    <h1 className="text-danger bg-primary">Welcome to React world</h1>
    <h1 className="text-warning bg-success">Welcome to React world</h1>
    <h1 className="text-info bg-dark">Welcome to React world</h1>
    </> 
)