import { createRoot } from "react-dom/client";
import './style.css'
createRoot(document.getElementById('root')).render(
    <>
    <h1 className="txt">Welcome to React world</h1>
    <h1>Welcome to React world</h1>
    <h1>Welcome to React world</h1>
    <h1 className="txt">Welcome to React world</h1>
    <h1>Welcome to React world</h1>
    <h1>Welcome to React world</h1>
    </>
)