import { createRoot } from "react-dom/client";
const clr={
    color:'green',
    background:'yellow'
}
createRoot(document.getElementById('root')).render(
    <>
    <h1 style={clr}>Welcome to React world</h1>
    </>
)