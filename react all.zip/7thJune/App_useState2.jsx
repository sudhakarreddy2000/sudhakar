import {useState} from 'react'
function App() {
   const [state, setState]= useState(100)
    return (
        <>
            <h2>App component</h2>
            <h2>{state+100}</h2>
            <h2>{state*10}</h2>
        </>
    )
}
export default App