import {useState} from 'react'
function App() {
const uid="Single Page Application"
const users=['Deepak','Sohail','Rahul','Kapil']
const person={
    f_name:'Manit',
    l_name:'Sharma',
    age:23
}
   const [state, setState]= useState(uid)
   const [data, setData]=useState(users)
   const [info, setInfo]=useState(person)
    return (
        <>
            <h2>App component</h2>
            <h2>{state}</h2>
            <h3>{data}</h3>
            <h3>{info.f_name}</h3>
        </>
    )
}
export default App