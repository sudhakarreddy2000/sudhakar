function App() {
    //function creation
    const demo=()=>{
        alert("Welcome to functions")
    }
    return (
        <>
            <h2>functions in react</h2>
            {/* {demo()} */}
            <button onClick={demo}>clickme </button>
            <button onMouseOver={demo}>mouseover </button>
            <button onMouseOut={demo}>mouseout </button>
        </>
    )
}
export default App