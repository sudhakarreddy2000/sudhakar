import {useState} from 'react'
function App() {
   const [state, setState]= useState("Stdent Tribe")
    return (
        <>
            <h2>App component</h2>
            <h2>{state}</h2>
        </>
    )
}
export default App