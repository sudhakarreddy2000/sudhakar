function Comp2() {
    return (
        <>
            <h2>class components</h2>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae labore commodi quas eligendi repellat ullam, suscipit fugit. Beatae ipsam quam distinctio placeat sed voluptatum a, laudantium accusamus velit fuga voluptas adipisci soluta perferendis quod. Aut quis atque error doloremque hic accusamus dolorum corporis eos fugiat ipsum! Voluptatibus, dolorem? Et quae enim vel rem suscipit. Fuga perspiciatis rem nemo ducimus nisi ut alias aspernatur suscipit, assumenda libero dolor placeat nihil, debitis facilis in mollitia. Alias, sapiente, obcaecati ex repellat excepturi voluptates perspiciatis omnis odio reprehenderit asperiores aspernatur, esse praesentium quae consequuntur sit optio quos at a veniam repellendus molestiae itaque commodi.
            </p>
        </>
    )
}
export default Comp2