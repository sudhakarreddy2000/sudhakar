import { createRoot } from "react-dom/client";
import Comp1 from "./Comp1";
import Comp2 from "./Comp2";
import Comp3 from "./Comp3";
createRoot(document.getElementById('root')).render(
    <>
<Comp1/>
<Comp2/>
<Comp3/>
<Comp1/>
    </> 
)