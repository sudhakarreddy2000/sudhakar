function Comp1() {
    return (
        <>
            <h2>function component</h2>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet ipsum totam tempora, iusto vero distinctio nobis consectetur rerum fugiat unde vitae commodi, corrupti nihil voluptatum ad id. Deleniti provident impedit natus facilis iure quam maxime. Recusandae assumenda, explicabo porro suscipit dolore, nobis quaerat nesciunt aliquid alias ea dolorum nostrum ipsa debitis tenetur placeat unde fuga beatae perferendis. Obcaecati quos quidem exercitationem deserunt doloribus minima. Provident nam exercitationem facere reiciendis laborum! Autem praesentium animi aspernatur quidem, at fuga quaerat magnam quod architecto commodi pariatur odit culpa incidunt molestias quo dignissimos rem repellat doloremque! Unde ut culpa modi est ratione ducimus at?
            </p>
        </>
    )
}
export default Comp1