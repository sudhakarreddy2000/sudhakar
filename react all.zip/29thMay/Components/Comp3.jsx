function Comp3() {
    return (
        <>
            <h2>Single page application</h2>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum repellat delectus ex fuga nisi autem cumque et porro culpa omnis facilis, necessitatibus eveniet minima numquam? Eveniet facere sed nam, doloremque similique animi iure incidunt eius maiores in placeat aliquam earum illo, qui suscipit ea reprehenderit ducimus? Tenetur assumenda facilis ullam molestiae veniam tempora sapiente quos porro corporis beatae. Consequuntur hic illum cum dignissimos animi quam omnis ea fuga distinctio commodi! Laudantium quisquam nesciunt quia in dolorum ratione nobis ut tempora minima perferendis. Temporibus impedit tempora eos eum similique nesciunt beatae accusamus natus facere nisi quasi, consequuntur at consequatur. Voluptatem, quas?
            </p>
        </>
    )
}
export default Comp3