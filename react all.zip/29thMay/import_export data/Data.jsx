let f_name="Rahul"
let l_name="Kumar"
let age=22
const fruits=['Apple','Grapes','Banana','Mangoes']
const person={
    name:'Peter',
    place:'USA'
}
function demo(){
    return "Single Page Application"
}
export default f_name
export {l_name, age, fruits, person, demo}