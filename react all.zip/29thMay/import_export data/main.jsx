import { createRoot } from "react-dom/client";
import f_name, {l_name,age,fruits,person,demo} from "./Data";
createRoot(document.getElementById('root')).render(
    <>
  <h2>importing and exporting data values</h2>
  <h2>{f_name}</h2>
  <h2>{l_name}</h2>
  <h2>{age}</h2>
  <h2>{fruits}</h2>
  <h2>{fruits[0]}</h2>
  <h2>{person.name}</h2>
  <h2>{demo()}</h2>
    </> 
)