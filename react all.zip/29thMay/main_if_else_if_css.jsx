import { createRoot } from "react-dom/client";
let obj=new Date();
let h=obj.getHours();
let message;
let clr={}
if(h<=12){
message="Good morning"
clr.color="green"
}else if(h>12 && h<=17){
    message="Good Afternoon"
    clr.color="red"
}else{
    message="Good Evening"
    clr.color="orange"
}
createRoot(document.getElementById('root')).render(
    <>
   <h2 style={clr}>{message}</h2>
    </> 
)