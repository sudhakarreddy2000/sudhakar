import { useState, useEffect } from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.css'
function App() {
    const [data, setData] = useState([])
    useEffect(() => {
        fetch('https://fakestoreapi.com/products')
            .then(res => res.json())
            //.then(json=>console.log(json))
            .then(json => setData(json))
    })
    return (
        <>
            <div className='container'>
                <div className='row'>
                    {data.map((item) =>
                        <div className='col-md-4'>
                            <div className="card" >
                                <img src={item.image} className="card-img-top" alt="..."/>
                                    <div class="card-body">
                                        <h5 className="card-title">{item.title}</h5>
                                        <p className="card-text">{item.price}</p>
                                        
                                    </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>




        </>
    )
}
export default App