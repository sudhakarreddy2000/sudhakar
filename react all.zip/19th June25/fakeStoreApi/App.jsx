import {useState, useEffect} from 'react'
function App() {
    const [data, setData]=useState([])
    useEffect(()=>{
fetch('https://fakestoreapi.com/products')
            .then(res=>res.json())
            //.then(json=>console.log(json))
            .then(json=>setData(json))
    })
       return (
        <>
        {/* {data.map((item)=><li>{item.title}</li>)} */}
        {data.map((item)=><img src={item.image} style={{width:'250px'}}/>)}
        </>
    )
}
export default App