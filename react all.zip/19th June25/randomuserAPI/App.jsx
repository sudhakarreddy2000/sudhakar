import {useState, useEffect} from 'react'
function App() {
    const [data, setData]=useState([])
    useEffect(()=>{
fetch('https://randomuser.me/api/?results=50')
      .then(response => response.json())
      //.then(json => console.log(json))
      .then(json => setData(json.results))
    })
       return (
        <>
    {data.map((item)=><li>{item.name.first}</li>)}
        </>
    )
}
export default App