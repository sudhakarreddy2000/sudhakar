import Comp1 from "./Comp1"
import Comp2 from "./Comp2"
function App() {
    const uid="React App"
    const pwd="abcd"
    const emps=['Charan','Preethy','Rama']
    return (
        <>
            <h2>App component</h2>
            <Comp1 uid={uid} pwd={pwd}/>
            <Comp2 emp={emps}/>
        </>
    )
}
export default App