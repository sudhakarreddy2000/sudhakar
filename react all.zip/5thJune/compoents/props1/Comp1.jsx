import React from 'react'
export default function Comp1(props) {
  return (
    <>
      <h2>Component1</h2>
      <h3>User id is {props.uid}</h3>
      <h3>Password is {props.pwd}</h3>
    </>
  )
}


