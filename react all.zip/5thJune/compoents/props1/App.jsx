import Comp1 from "./Comp1"
function App() {
    return (
        <>
            <h2>App component</h2>
            <Comp1 uid="React App" pwd="abcd"/>
        </>
    )
}
export default App