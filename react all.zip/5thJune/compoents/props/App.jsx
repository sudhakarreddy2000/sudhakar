import Comp1 from "./Comp1"
function App() {
    return (
        <>
            <h2>App component</h2>
            <Comp1 uid="React App"/>
        </>
    )
}
export default App