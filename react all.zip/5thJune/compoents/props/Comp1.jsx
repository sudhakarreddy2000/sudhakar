import React from 'react'
export default function Comp1(props) {
  return (
    <>
      <h2>Component1</h2>
      <h3>Hello {props.uid}</h3>
    </>
  )
}


