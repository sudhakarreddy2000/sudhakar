import React from 'react'
export default function Comp1(props) {
  return (
    <>
      <h2>Component1</h2>
      <img src={props.p1} style={{width:'200px'}}/>
    </>
  )
}


