import Comp1 from "./Comp1"
import Comp2 from "./Comp2"
import pic1 from './images/boy.jpeg'
import pic2 from './images/smile.png'
function App() {
    return (
        <>
            <h2>App component</h2>
            <Comp1 p1={pic1}/>
            <Comp2 p2={pic2}/>
        </>
    )
}
export default App