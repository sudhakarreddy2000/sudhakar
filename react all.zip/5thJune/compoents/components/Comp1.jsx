function Comp1() {
    return (
        <>
            <h2>Component1</h2>
        </>
    )
}
export default Comp1