import React from 'react'
import Comp3 from './Comp3'
export default function Comp2({data}) {
  return (
    <>
      <h3>Component2</h3>
      <Comp3 data={data}/>
      
    </>
  )
}
