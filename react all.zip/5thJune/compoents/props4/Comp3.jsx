import React from 'react'
export default function Comp3({data}) {
  return (
    <>
      <h3>Component 3</h3>
      <h3>Hello {data}</h3>
    </>
  )
}
