import React from 'react'
import Comp2 from './Comp2'
export default function Comp1({data}) {
  return (
    <>
      <h2>Component1</h2>
    <Comp2 data={data}/>
    </>
  )
}


