import Comp1 from "./Comp1"
function App() {
    const data="Student Tribe"
    return (
        <>
            <h2>App component</h2>
        <Comp1 data={data}/>
        </>
    )
}
export default App